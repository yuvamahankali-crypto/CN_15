# Experiment 15: Operating System Detection Using Nmap

## Aim
Use Nmap OS detection and service/version detection on an authorized lab host.

## Repository contents
- `README.md` — overview and run notes
- `Practical-Documentation.md` — procedure, examples, observation template, and conclusion
- `Original-Practical.docx` — supplied lab handout
- `evidence/` — add genuine screenshots and logs here
- `diagrams/authorized-nmap-workflow.svg` — workflow diagram

## Evidence
Add your own screenshots from the lab run. Do not submit sample output as if it were captured from your machine.

## GitHub upload
Create a public repository, upload these files, add actual evidence, and commit the changes.
